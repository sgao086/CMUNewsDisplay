# filename : linear_regression.py
#
# the names of the group members:
# Jianping DENG,jianpind@andrew.cmu.edu
# Shan GAO,shangao@andrew.cmu.edu
# Tan Tan (Zoe) KWAN,tantank@andrew.cmu.edu
# Takuya FUNAHASHI,tfunahas@andrew.cmu.edu
# Yunzhou NING,yunzhoun@andrew.cmu.edu

# This file is used to do the linear regression, the data is integrated based on time sequence
# Y is the change(delta) of the Dow Jones index
# x1 to x5 is the
# The data is not enough to get a robust result, but it's enough for a prototype
import pandas as pd
from analyze_date  import date_report
import numpy as np
import statsmodels.api as sm
# Read data from our data source
path = 'concat.xlsx'
df = pd.read_excel(path)
# Read the data of dowjones index
df_dowJones = pd.read_csv('dowjones.csv')
# the list difference is used to calculate the change of each date
difference = [0.0]
for i in range(1,len(df_dowJones)):
    difference.append(df_dowJones.iloc[i]['Close'] - df_dowJones.iloc[i-1]['Close'])
# a new column is added by the following code, this column shows the change of each date from its previous date
df_dowJones['difference'] = difference
y = df_dowJones.loc[241:245]['difference']#To get the data 23th Sep to 27th Sep
y.index = [0,1,2,3,4]
datelist = [str(x) for x in range(20190923, 20190928)]
# Each statement use the function defined in analyze_channels.py to calculate the average sentiment for each date
BBC = np.array([date_report('BBC',df)[key] for key in date_report('BBC',df).keys() if key in datelist])
Renmin = np.array([date_report('Renmin',df)[key] for key in date_report('Renmin',df).keys() if key in datelist])
NHK = np.array([date_report('NHK',df)[key] for key in date_report('NHK',df).keys() if key in datelist])
Aljazeera = np.array([date_report('Aljazeera',df)[key] for key in date_report('Aljazeera',df).keys() if key in datelist])
Folha = np.array([date_report('Folha',df)[key] for key in date_report('Folha',df).keys() if key in datelist])
# Do the linear regression
X = pd.DataFrame({'BBC': BBC,'Renmin':Renmin,'NHK': NHK, 'Aljazeera':Aljazeera,'Folha':Folha})
X= sm.add_constant(X)
est=sm.OLS(y,X).fit()
print(est.summary())

