import requests
import time
from bs4 import BeautifulSoup
import pandas as pd

## get the full html per day if needed -> it works!
# res = requests.get('https://www.bbc.com/news')
# fullBBCHtml = res.text
# date = time.strftime("%Y-%m-%d")
# full = open('fullBBCHtml_'+ date + '.txt','wt')
# full.write(fullBBCHtml)
# full.close()

#parse the html with beautifulSoup
response = requests.get('http://www.bbc.co.uk/news')
doc = BeautifulSoup(response.text, 'html.parser') #   without.text, it will parse in as strings anyway
# headlines = doc.find_all('h3')
# print(headlines)
links = doc.find_all('a', {'class': 'gs-c-promo-heading'})

today = time.strftime("%Y%m%d")
f = open(today + '-bbc' + '.txt','wt', encoding = 'utf-8')

data = {}

title_list = []
link_list = []
date_list = []
realtext_list = []

for link in links:
    try:
        subPage = requests.get(link['href'])
        url = link['href']
        son_doc = BeautifulSoup(subPage.text, 'html.parser')     #it shall be perfectly fine if it can be parsed.
        #print('absolute url')
    except:
        url = 'https://www.bbc.com' + link['href']                #if cannot be parsed, they should be relatve URL that needs to be fixed.
        subPage = requests.get(url)
        son_doc = BeautifulSoup(subPage.text, 'html.parser')
        #print('relative url')

    if son_doc.find('h1') is None:
        continue
    else:
        headings = son_doc.find('h1').text

#extract the date
    try:
        date = son_doc.find('time', {'class': 'date'}).attrs["datetime"]
    except:
        date = today

    # try:
    #     summaries = son_doc.find('p', {'class': 'story-body__introduction'}).text
    # except:
    #     summaries = 'N/A'
    try:
        if son_doc.find('p', {'class': 'story-body__introduction'}) is None:
            summaries = son_doc.find_all('div', {'class': 'vxp-media__summary'})[0].find('p').text
        else:
            summaries = son_doc.find('p', {'class': 'story-body__introduction'}).text
    except:
            summaries = 'N/A'

# put them into separate lists
    data['title'] = headings
    data['link'] = url
    data['date'] = date
    data['text'] = summaries

    title_list.append(headings)
    link_list.append(url)
    date_list.append(date)
    realtext_list.append(summaries)

    f.write(str(data))
    f.write('\n')
f.close()

print(title_list)

#putting in DataFrame
dataForDF = {'title':title_list, 'link': link_list, 'date': date_list, 'text':realtext_list}
df = pd.DataFrame(dataForDF)
excel_path = str(today) + '_bbc' +'.xlsx'
writer = pd.ExcelWriter(excel_path)
df.to_excel(writer, columns=['title', 'link', 'date', 'text'], index=False,encoding='utf-8',sheet_name='Sheet')
writer.save()
# print(len(headings))
# print(len(date))
# print(len(summaries))

# more standardized format after clicking into the article. i.e. put in the structure