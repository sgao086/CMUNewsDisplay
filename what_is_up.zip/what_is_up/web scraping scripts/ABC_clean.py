import urllib
from urllib.request import Request, urlopen
from bs4 import BeautifulSoup
import ssl
import pandas as pd
import time
now = time.strftime('%Y%m%d',time.localtime(time.time()))
from openpyxl.workbook import Workbook
# set the safety
ssl._create_default_https_context = ssl._create_unverified_context
req = Request('https://www.abc.net.au/news/', headers={'User-Agent': 'Mozilla/5.0'})
webpage = urlopen(req).read()
html = webpage.decode('utf-8')
#print(html)
soup = BeautifulSoup(html, features='html.parser')
allnews = soup.find_all('li', {"class": "doctype-article"})
title_list = []
link_list = []
date_list = []
realtext_list = []
topics_list = []
for piece in allnews:
    try:
        date = piece['data-last-published']
    except KeyError:
        continue
    link = 'https://www.abc.net.au' + piece.a['href']
    title = piece.a.string
    req1 = Request(link, headers={'User-Agent': 'Mozilla/5.0'})
    try:
        webpage1 = urlopen(req1).read()
    except urllib.error.URLError:
        continue
    html1 = webpage1.decode('utf-8')
    # print(html)
    soup1 = BeautifulSoup(html1, features='html.parser')
    topic = soup1.find('p', {"class": "topics"})
    if topic != None:
        topics = [x.string for x in topic.find_all('a')]

    text = soup1.find_all('p')
    realtext = ""
    for item in text:
        if item.string != None:
            if item.string == 'ABC teams share the story behind the story and insights into the making of digital, TV and radio content.':
                break
            else:
                realtext += item.string
    title_list.append(title)
    link_list.append(link)
    date_list.append(date)
    realtext_list.append(realtext)
    topics_list.append(topics)
#examine if the length of each list is the same, so it can be transformed to dataframe
print(len(title_list))
print(len(link_list))
print(len(date_list))
print(len(realtext_list))
print(len(topics_list))
data = {'newsTitle':title_list, 'link': link_list, 'date': date_list, 'text':realtext_list, 'topics': topics_list}
# write txt
path = r'ABC' + now + '.txt'
f = open(path, 'w', encoding='utf-8')
for title, link, date, text, topics in zip(title_list,link_list,date_list,realtext_list, topics_list):
    f.write(str({'newsTitle':title, 'link': link, 'date': date, 'text':realtext, 'topics': topics})+'\n')
# write excel
excel_path = r''+ now +'ABC'+ '.xlsx'
df = pd.DataFrame(data)
writer = pd.ExcelWriter(excel_path)
df.to_excel(writer, columns=['newsTitle', 'link', 'date', 'text', 'topics'], index=False,encoding='utf-8',sheet_name='Sheet')
writer.save()
