from urllib.request import urlopen  # b_soup_1.py
from bs4 import BeautifulSoup
import datetime
import pandas as pd

aljazeera_url = "https://www.aljazeera.com"
aljazeera_response = urlopen(aljazeera_url)

aljazeera_bsyc = BeautifulSoup(aljazeera_response.read(), "lxml")

datas = {}

sm7News = aljazeera_bsyc.find_all(class_="col-sm-7 news-trending-txt")
for sm7article in sm7News:
    data_title = sm7article.a.string
    data_url = aljazeera_url + sm7article.a.get("href")
    if "news" in data_url:
        data_date = datetime.date((int)("20"+data_url[-20:-18]), int(data_url[-18:-16]), int(data_url[-16:-14]))
    else:
        data_date = datetime.date.today()
    datas[data_title] = [data_url, None, data_date]
    
sm7News = aljazeera_bsyc.find_all(class_="col-sm-7 mts-article-content")
for sm7article in sm7News:
    data_title = sm7article.a.string
    data_url = aljazeera_url + sm7article.a.get("href")
    data_summary = sm7article.find("p", class_="mts-article-p").string
    if "news" in data_url:
        data_date = datetime.date((int)("20"+data_url[-20:-18]), int(data_url[-18:-16]), int(data_url[-16:-14]))
    else:
        data_date = datetime.date.today()
    datas[data_title] = [data_url, data_summary, data_date]
    
    
ep4News = aljazeera_bsyc.find_all(class_="ep4-content")
for ep4article in ep4News:
    data_title = ep4article.find(class_="ep4-title-wrap ep4-inpictures-title ep4-video-title").a.string
    data_url = aljazeera_url + ep4article.find(class_="ep4-title-wrap ep4-inpictures-title ep4-video-title").a.get("href")
    data_summary = ep4article.find("p",class_="ep4-description").string
    if "news" in data_url:
        data_date = datetime.date((int)("20"+data_url[-20:-18]), int(data_url[-18:-16]), int(data_url[-16:-14]))
    else:
        data_date = datetime.date.today()
    datas[data_title] = [data_url, data_summary, data_date]

    
opnionArticles = aljazeera_bsyc.find_all(class_="op-widget-des")

for opinion in opnionArticles:
    data_title = opinion.find(class_="op-widget-summary").a.string
    data_url = aljazeera_url + opinion.find(class_="op-widget-summary").a.get("href")
    if "news" in data_url:
        data_date = datetime.date((int)("20"+data_url[-20:-18]), int(data_url[-18:-16]), int(data_url[-16:-14]))
    else:
        data_date = datetime.date.today()
    datas[data_title] = [data_url, None, data_date]

    
datas_df = pd.DataFrame.from_dict([[key, datas[key][0], datas[key][1], datas[key][2]] for key in datas.keys()])
datas_df = datas_df.rename(columns={0:"title", 1:"link", 2:"text", 3:"date"})
datas_df = datas_df[["title","link","date","text"]]
    
print(datas_df)

today = datetime.date.today()
datas_df.to_excel(str(today).replace("-","")+'aljazeera.xlsx', sheet_name='new_sheet_name')    
