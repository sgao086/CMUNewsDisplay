from urllib.request import urlopen  # b_soup_1.py
from bs4 import BeautifulSoup
import datetime
import pandas as pd
import re

folha_url = "https://www1.folha.uol.com.br/internacional/en/"
folha_response = urlopen(folha_url)

folha_bsyc = BeautifulSoup(folha_response.read(), "lxml")

datas = {}

divs = folha_bsyc.find_all("div", class_="c-headline__content")

for div in divs:
    data_title = div.find("h2").string.string.replace("  ","").replace("\n","")
    data_url = div.find("a").get("href")
    data_summary = div.find("p", class_="c-headline__standfirst").string.replace("  ","").replace("\n","")
    if (div.find("time") != None):
        date_year = (int)(div.find("time").get("datetime")[0:4])
        date_month = (int)(div.find("time").get("datetime")[5:7])
        date_day = (int)(div.find("time").get("datetime")[8:10])
        data_date = datetime.date(date_year, date_month, date_day)
    else:
        data_date = datetime.date.today()
    datas[data_title] = [data_url, data_summary, data_date]

datas_df = pd.DataFrame.from_dict([[key, datas[key][0], datas[key][1], datas[key][2]] for key in datas.keys()])
datas_df = datas_df.rename(columns={0:"title", 1:"link", 2:"text", 3:"date"})
datas_df = datas_df[["title","link","date","text"]]
    
print(datas_df)

today = datetime.date.today()

datas_df.to_excel(str(today).replace("-","")+'folha.xlsx', sheet_name='new_sheet_name')