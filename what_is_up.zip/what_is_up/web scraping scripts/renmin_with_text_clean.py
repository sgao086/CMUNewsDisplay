# Renmin website has a archive including all the history webpages, so it's easy to webscrape all of them in one program
import urllib
from urllib.request import Request, urlopen
from bs4 import BeautifulSoup
import pandas as pd
date = []

for i in range(23,31):
    date.append('09' + str(i))
for i in range(1,5):
    date.append('100' + str(i))

req = Request('http://en.people.cn/review/2019'+ '0101' +'.html', headers={'User-Agent': 'Mozilla/5.0'})
webpage = urlopen(req).read()
html = webpage.decode('utf-8')
soup = BeautifulSoup(html, features='html.parser')

a = soup.find_all('a')
title = [x.string for x in a]
indexBegin = 0
indexEnd = 0
for i, item in enumerate(title):
    if item == 'Video':
        indexBegin = i
    if item == 'Beijing Today':
        indexEnd = i
# meaningless is a list containing unrelevant data
# This list is used to do data cleaning
meaningless = set(title[:indexBegin+1]) | set(title[indexEnd:])
meaningless.update(['Latest News','Video: We Are China','Columnist','National','Science & Tech','Life & Health','Beautiful China','Odd News','The China path offers a new way for a world in constant flux'])



# each iteration Webscrapes one source data we need at one date
for eachday in date:
    df = pd.DataFrame(columns=['title', 'link', 'date', 'text'])
    data = []
    count = 0
    # Sometimes the url is broken, the try-catch is set to handle thi
    try:
        req = Request('http://en.people.cn/review/2019'+ eachday +'.html', headers={'User-Agent': 'Mozilla/5.0'})

        webpage = urlopen(req).read()
        html = webpage.decode('utf-8')
        soup = BeautifulSoup(html, features='html.parser')
        a = soup.find_all('a')
    except urllib.error.HTTPError:
        print(eachday+"is exception")
        continue
    for item in a:
        if item.string not in meaningless:
            link = item['href']
            # Sometimes the url is broken, the try-catch is set to handle thi
            try:
                req1 = Request(link, headers={'User-Agent': 'Mozilla/5.0'})
                webpage1 = urlopen(req1).read()
                html1 = webpage1.decode('utf-8')
                soup1 = BeautifulSoup(html1, features='html.parser')
                text = soup1.find_all('p')
                realtext = ""
                for ele in text:
                    if ele.a == None:
                        if ele.string != None:
                            realtext += ele.string
                data.append({'title': item.string, 'link': item['href'], 'date': eachday, 'text': realtext})# revision
                if realtext != '':
                    df.loc[count] = [item.string, item['href'], eachday, realtext]
                    count += 1
            except:
                continue
    #result is saved in txt as well as .xlsx
    path = 'renmin' + eachday + '.txt'
    print(eachday, 'is finished')
    f = open(path, 'w', encoding='utf-8')
    for item in data:
        f.write(str(item) + '\n')
    print(eachday, 'is filed')
    excel_path = r'2019' + eachday + 'renmin' + '.xlsx'
    writer = pd.ExcelWriter(excel_path)
    df.to_excel(writer, columns=['title', 'link', 'date', 'text'], index=False,encoding='utf-8',sheet_name='Sheet')
    writer.save()

