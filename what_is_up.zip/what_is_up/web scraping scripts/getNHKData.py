from urllib.request import urlopen
from bs4 import BeautifulSoup
import pandas as pd
import requests
import datetime
import json

nhk_world_url = 'https://www3.nhk.or.jp/nhkworld/data/en/news/all.json'

nhk_world_response = requests.get(nhk_world_url)

if nhk_world_response.status_code == 200:
    datas = nhk_world_response.json()

datas = datas['data']   
datas_df = pd.DataFrame.from_dict([[data['title'],
                                    'https://www3.nhk.or.jp'+data['page_url'],
                                   datetime.date(int(data['id'][:4]), int(data['id'][4:6]), int(data['id'][6:8])),
                                   data['description'].replace("Please click on the image to watch.",""),
                                   data['id'],
                                   data['categories']] for data in datas])
datas_df = datas_df.rename(columns={0:"title", 1:"link", 2:"date", 3:"text", 4:"id", 5:"categories"})

print(datas_df)

today = datetime.date.today()
datas_df.to_excel(str(today).replace("-","")+'nhk.xlsx', sheet_name='new_sheet_name')