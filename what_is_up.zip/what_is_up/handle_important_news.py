# filename : handle_important_news.py
#
# the names of the group members:
# Jianping DENG,jianpind@andrew.cmu.edu
# Shan GAO,shangao@andrew.cmu.edu
# Tan Tan (Zoe) KWAN,tantank@andrew.cmu.edu
# Takuya FUNAHASHI,tfunahas@andrew.cmu.edu
# Yunzhou NING,yunzhoun@andrew.cmu.edu

# This file is used to process the downloaded dataset(in JSON format) important news
# The result is saved with many pieces of news containing the column 'title, 'link', 'date', 'text', 'likes', 'filtered_text', 'filtered_title'
import json
import pandas as pd
import xlsxwriter
from readData_Vfinal import remove_stopwords
import nltk


df_important = pd.DataFrame(columns=['title', 'link', 'date', 'text', 'likes'])
count = 0
component = []
# Inside the dataset, each file named as news_XXXX in JSON format
# The component list is to store all the
for n in range(1,81224):
    s = "%07d" % n
    component.append(s)
# in the each iteration of this loop, one file is read and informaiton is extracted and appended to the df_important
for number in component:
    path = 'important_news_dataset/news_'+number+'.json'
    f = open(path, 'r')
    new_dict = json.loads(f.readline())
    title = new_dict['title']
    link = new_dict['url']
    date = new_dict['published']
    text = new_dict['text']
    likes = new_dict['thread']['social']['facebook']['likes']# likes means how many people like it on the facebook
    # Only pick a part of news in the dataset, otherwise it will be too much
    if int(likes) % 10 == 0:
        df_important.loc[count] = [title, link, date, text, likes]
        count += 1
print('We have read all the data in the important news dataset and picked ' + str(count) + ' of them')
# remove stopwords of title and text, add two more columns to the dataFrame, refers to the readData_Vfinal for more information
df_important = remove_stopwords(df_important)
excel_path = r'important/important_news.xlsx'
writer = pd.ExcelWriter(excel_path)
df_important.to_excel(writer, columns=['title', 'link', 'date', 'text', 'likes','filtered_text','filtered_title'], index=False,encoding='utf-8',sheet_name='Sheet',engine='xlsxwriter')
writer.save()
