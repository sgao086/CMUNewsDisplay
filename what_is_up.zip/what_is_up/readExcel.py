# filename : readExcel.py
#
# the names of the group members:
# Jianping DENG,jianpind@andrew.cmu.edu
# Shan GAO,shangao@andrew.cmu.edu
# Tan Tan (Zoe) KWAN,tantank@andrew.cmu.edu
# Takuya FUNAHASHI,tfunahas@andrew.cmu.edu
# Yunzhou NING,yunzhoun@andrew.cmu.edu

# This module provides a valuable function applied at many other place
# This function basically resolves a problem described below:
# We want to store our data locally and statically in a .xlsx file(otherwise, the process of data cleaning, processing, integration takes too much time)
# But the data type of column filtered_text and filtered_title is list, if we write the file and read it from file, it will be string
# This function change these two columns back to list
import re
import pandas as pd
def modifyDf(df):
    ft_list = []
    for line in df['filtered_text']:
        df_line_list = re.findall(r"'.*'" , line);
        for df_line in df_line_list:
            ft_list.append(df_line.replace("'", "").split(", "))
    df['filtered_text'] = pd.Series(ft_list)
    ft_list = []
    for line in df['filtered_title']:
        df_line_list = re.findall(r"'.*'" , line);
        for df_line in df_line_list:
            ft_list.append(df_line.replace("'", "").split(", "))
    df['filtered_title'] = pd.Series(ft_list)
    return df
#testing code
if __name__ == '__main__':
    df = pd.read_excel("concat.xlsx")
    df = modifyDf(df)
    print(type(df.iloc[0]['filtered_title']))# should display<class 'list'>