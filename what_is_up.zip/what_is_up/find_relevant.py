# filename : find_relevant.py
#
# the names of the group members:
# Jianping DENG,jianpind@andrew.cmu.edu
# Shan GAO,shangao@andrew.cmu.edu
# Tan Tan (Zoe) KWAN,tantank@andrew.cmu.edu
# Takuya FUNAHASHI,tfunahas@andrew.cmu.edu
# Yunzhou NING,yunzhoun@andrew.cmu.edu
#
# this code define find_by_title()

import pandas as pd
from readExcel import modifyDf

df = pd.read_excel('concat.xlsx')
df = modifyDf(df)

# input is a piece of news in Series
# return a dataframe of news relevant to the input, sorted by the sentiment "polarity_of_title"
def find_by_title(piece):
    searchWords = piece['filtered_title']
    set_searchWords = set(searchWords)
    df_match = pd.DataFrame(columns=['title','text','date','searchDate','link','polarity_of_title'])
    count = 0
    for i in range(len(df)):
        check_series = df.iloc[i]
        check = df.iloc[i]['filtered_title']
        match = set_searchWords.intersection(set(check))
        # if the match is not empty, the block in the if will be executed
        if match:
            df_match.loc[count] = check_series
            count += 1
        # only 20 is enough, otherwise may search all the df, takes too long
        if count == 20:
            break
    df_match = df_match.drop_duplicates(subset='title')
    df_match = df_match.sort_values(by='polarity_of_title', ascending=False)
    return df_match

# testing code
if __name__ == '__main__':
    print(df.iloc[2]['title'])
    df1 = find_by_title(df.iloc[2])
    for i in range(len(df1)):
        print(df1.iloc[i]['title'])
