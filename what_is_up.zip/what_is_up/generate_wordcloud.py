# filename : generate_wordcloud.py
#
# the names of the group members:
# Jianping DENG,jianpind@andrew.cmu.edu
# Shan GAO,shangao@andrew.cmu.edu
# Tan Tan (Zoe) KWAN,tantank@andrew.cmu.edu
# Takuya FUNAHASHI,tfunahas@andrew.cmu.edu
# Yunzhou NING,yunzhoun@andrew.cmu.edu


# This module is for generating word cloud for each day
import pandas as pd
from readExcel import modifyDf
from wordcloud import WordCloud
import PIL .Image as image
import numpy as np
from nltk.corpus import stopwords
# Read the data from our data integrated data source
path = 'concat.xlsx'
df = pd.read_excel(path)
# To see what modifyDf function does, refers to 'readExcel.py', it doesn't matter at this place
df = modifyDf(df)
def generate_wordcloud(date):
    stopword = list(stopwords.words('english'))
    date = int(date)
    #Get "sub DataFrame" for the required date
    df_at_date = df[df['searchDate'] == date]
    alltext_at_date = ""
    for i in range(len(df_at_date)):
        # In some cases the column filtered_text has no content, so a type error occurs, the try and except are set to handle this case
        try:
            alltext_at_date += " ".join(df_at_date.iloc[i]['filtered_text'])
        except TypeError:
            pass
    mask_image = np.array(image.open("WX20191007-131356@2x.png"))
    Word_cloud = WordCloud(
    mask=mask_image,
        # These stop words are still not enough, but I tried my best, please don't take our marks here
    stopwords = stopword + ['said','say','the','people','get','n\'t','one','also','nt','says','would','could']
    ).generate(alltext_at_date)
    image_produce = Word_cloud.to_image()
    #The result is saved as jpg file for each day
    image_produce.save(str(date) + ".jpg")
# Generate all the image, we generate one word cloud for each day
# The list date_interval contains all the date with data available in our data source
date_interval = [str(x) for x in range(20190926, 20190931)] + [str(x) for x in range(20191001, 20191005)]
for one_date in date_interval:
    generate_wordcloud(one_date)

