# filename : news_eachsource.py
#
# the names of the group members:
# Jianping DENG,jianpind@andrew.cmu.edu
# Shan GAO,shangao@andrew.cmu.edu
# Tan Tan (Zoe) KWAN,tantank@andrew.cmu.edu
# Takuya FUNAHASHI,tfunahas@andrew.cmu.edu
# Yunzhou NING,yunzhoun@andrew.cmu.edu
#
# this module help to read dataset(dataframe) from concat.xlsx
# it will used by world_news.py

import pandas as pd

main_df = pd.read_excel('concat.xlsx')

def get_news_for_source(date, source):
    date = int(date)
    df = main_df[(main_df['source'] == source) & (main_df['searchDate'] == date) & (main_df['polarity_of_title'] != 0)]
    df = df.sort_values(by='polarity_of_title', ascending=False)
    df = df.iloc[[0,1,len(df)-1]]
    return df


def get_news_for_source_OrderByIndex(date, source):
    date = int(date)
    df = main_df[(main_df['source'] == source) & (main_df['searchDate'] == date) & (main_df['polarity_of_title'] != 0)]
    df = df.sort_index()
    return df