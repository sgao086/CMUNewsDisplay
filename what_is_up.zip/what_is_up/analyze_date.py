# filename : analyze_date.py
#
# the names of the group members:
# Jianping DENG,jianpind@andrew.cmu.edu
# Shan GAO,shangao@andrew.cmu.edu
# Tan Tan (Zoe) KWAN,tantank@andrew.cmu.edu
# Takuya FUNAHASHI,tfunahas@andrew.cmu.edu
# Yunzhou NING,yunzhoun@andrew.cmu.edu

# This file is used to analyze data based on channel, in the give a channel and type of sentiment,
# the function will return a dict which key is the date, and the value is the average sentiment value for that channel at taht date

import pandas as pd
import numpy as np


def date_report(channel, df, sentiment = 'polarity_of_title'):
    df_channel = df[(df['source'] == channel) & (df[sentiment] != 0)]
    date_set = {unique_date for unique_date in df_channel['searchDate']} # a set of int
    sentiment_dict = {}
    #calculate the average sentiment value for each date
    for oneDate in date_set:
        df_oneDate = df_channel[(df_channel['searchDate'] == oneDate) & (df_channel['source'] == channel)]
        sentiment_value = np.array(df_oneDate[sentiment]).mean()
        sentiment_dict[str(oneDate)] = sentiment_value
    return sentiment_dict

# Testing code
if __name__ == '__main__':
    path = 'concat.xlsx'
    df = pd.read_excel(path)
    print(date_report('Renmin', df, 'polarity_of_text'))