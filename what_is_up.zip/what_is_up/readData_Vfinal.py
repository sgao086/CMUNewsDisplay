# filename : readData_Vfinal.py
#
# the names of the group members:
# Jianping DENG,jianpind@andrew.cmu.edu
# Shan GAO,shangao@andrew.cmu.edu
# Tan Tan (Zoe) KWAN,tantank@andrew.cmu.edu
# Takuya FUNAHASHI,tfunahas@andrew.cmu.edu
# Yunzhou NING,yunzhoun@andrew.cmu.edus
#
# this code make concat.xlsx from search results

import numpy as np
import pandas as pd
import glob
import re
from textblob import TextBlob
from nltk.corpus import stopwords

# input fileName
# return string formatted date "YYYYMMDD"
def getSearchDateFromFileName(s):
    matchResult = re.search(r'\d\d\d\d\d\d\d\d', s)
    if(matchResult != None):
        return matchResult.group()
    matchResult = re.search(r'\d\d\d\d.\d\d.\d\d', s)
    if(matchResult != None):
        matchString = matchResult.group()
        matchString = matchString[0:4]+matchString[5:7]+matchString[8:10]
        return matchString
    matchResult = re.search(r'\d\d.\d\d.\d\d\d\d',s)
    matchString = matchResult.group()
    matchString = matchString[-4:] + matchString[0:2] + matchString[3:5]
    return matchString

# make Data Frame from Web scraping files(News Data)
# argument is the file path of excel(web scraping data)
# return data frame of news data
def dfFactory(filePath):
    if "aljazeera" in filePath:
        aljazeera_df = pd.read_excel(filePath, index_col=0)
        # aljazeera_df = aljazeera_df['date'].str[0:10]
        aljazeera_df['source'] = "Aljazeera"
        aljazeera_df['date'] = aljazeera_df['date'].dt.strftime('%Y%m%d')
        aljazeera_df['searchDate'] = getSearchDateFromFileName(filePath)
        # data cleaning
        aljazeera_df['text'] = aljazeera_df['text'].fillna("")
        return aljazeera_df
    elif "folha" in filePath:
        folha_df = pd.read_excel(filePath, index_col=0)
        folha_df['source'] = "Folha"
        folha_df['date'] = folha_df['date'].dt.strftime('%Y%m%d')
        folha_df['searchDate'] = getSearchDateFromFileName(filePath)
        return folha_df
    elif "nhk" in filePath:
        nhk_df = pd.read_excel(filePath, index_col=0)
        nhk_df['source'] = "NHK"
        nhk_df['date'] = nhk_df['date'].dt.strftime('%Y%m%d')
        nhk_df['searchDate'] = getSearchDateFromFileName(filePath)     
        del nhk_df['id']
        return nhk_df
    elif "ABC" in filePath:
        abc_df = pd.read_excel(filePath)
        abc_df = abc_df.rename(columns={'newsTitle': 'title'})
        # data cleanig
        abc_df = abc_df.drop_duplicates(subset='link')
        abc_df['source'] = "ABC"
        abc_df['date'] = abc_df['date'].astype(str)
        abc_df['date'] = abc_df['date'].str[0:10]
        abc_df['date'] = abc_df['date'].str.replace("-","")
        abc_df['searchDate'] = getSearchDateFromFileName(filePath)     
        return abc_df
    elif "WSJ" in filePath:
        wsj_df = pd.read_excel(filePath)
        wsj_df['source'] = "WSJ"
        wsj_df['date'] = wsj_df['date'].str.replace("-","")
        wsj_df['searchDate'] = getSearchDateFromFileName(filePath)     
        return wsj_df
    elif "South Africa" in filePath:
        sa_df = pd.read_excel(filePath)
        sa_df['source'] = "South Africa"
        sa_df['searchDate'] = getSearchDateFromFileName(filePath)     
        return sa_df
    elif "renmin" in filePath:
        renmin_df = pd.read_excel(filePath)
        renmin_df['source'] = "Renmin"
        renmin_df['date'] = renmin_df['date'].astype(str)
        renmin_df['date'] = "2019" + renmin_df['date'].str.zfill(4)
        renmin_df['searchDate'] = getSearchDateFromFileName(filePath)     
        return renmin_df
    elif "bbc" in filePath:
        bbc_df = pd.read_excel(filePath)
        # data cleaning
        bbc_df = bbc_df.drop_duplicates(subset='link')
        bbc_df = bbc_df.dropna(axis=0, how='any', thresh=None, subset=None, inplace=False)
        bbc_df['source'] = "BBC"
        bbc_df['date'] = bbc_df['date'].astype(str)
        bbc_df['date'] = bbc_df['date'].str.replace("-","")
        bbc_df['searchDate'] = getSearchDateFromFileName(filePath)     
        return bbc_df

# argument is folder Path, which folder only include excel files
# return data frame of news data
# this function marge multi data frame to single big data frame for analysis
def readDatasets(datasetFolderName):
    fileNameList = glob.glob(datasetFolderName + "/*")

    df_list = []
    for fileName in fileNameList:
        df_list.append(dfFactory(fileName))

    df = pd.DataFrame()
    for i in range(0, len(df_list)):
        df = df.append(df_list[i])
    df = df[['source', 'searchDate','title', 'link', 'date', 'text', 'categories']]

    return df
# This function takes a DataFrame as the input and gives a processed DataFrame as output
# The input DataFrame should include column 'text' and 'title'
# Inside the function, the textblob module is used to do the sentiments analysis and add four more columns for the input dataframe
# The added for columns are 'polarity_of_text', 'polarity_of_title', 'subjectivity_of_text', 'subjectivity_of_title', respectively
def add_sentiment(df):
    polarity_of_title = []
    polarity_of_text = []
    subjectivity_of_title = []
    subjectivity_of_text = []
    # In this loop, the text and title is extracted from the Input DataFrame
    # Then, the subjectivity and polarity value is calculated for each of them, and then appended to the list respectively
    for i in range(0, len(df)):
        text = df.iloc[i]['text']
        title = df.iloc[i]['title']
        if isinstance(title, float):
            title = str(title)
        polarity_of_text.append(TextBlob(text).sentiment.polarity)
        polarity_of_title.append(TextBlob(title).sentiment.polarity)
        subjectivity_of_text.append(TextBlob(text).sentiment.subjectivity)
        subjectivity_of_title.append(TextBlob(title).sentiment.subjectivity)
    df['polarity_of_text'] = polarity_of_text
    df['polarity_of_title'] = polarity_of_title
    df['subjectivity_of_text'] = subjectivity_of_text
    df['subjectivity_of_title'] = subjectivity_of_title
    return df
# This function takes a DataFrame as the input, and gives a processed DataFrame as the output
# The input DataFrame should contain column 'text' and 'title'.
# This function use textblob module and cut off the stopwords, after that the contents without stopwords are saved in a list
# Fianlly, 2 more columns are added to the original DataFrame, one is 'filtered_text', one is 'filtered_title'
def remove_stopwords(df):
    stopword = list(stopwords.words('english'))
    stopword += [word.capitalize() for word in stopword]
    filtered_text_list = []
    filtered_title_list = []
    # In some cases, text and title are read as float type, this causes type error, so the try and except is set to handle this situation
    for i in range(0, len(df)):
        try:
            text = TextBlob(df.iloc[i]['text']).words
            title = TextBlob(df.iloc[i]['title']).words
        except TypeError:
            text = ""
            title = ""
        filtered_text = [word.lower() for word in text if word not in stopword]
        filtered_title = [word.lower() for word in title if word not in stopword]
        filtered_text_list.append(filtered_text)
        filtered_title_list.append(filtered_title)
    df['filtered_text'] = filtered_text_list
    df['filtered_title'] = filtered_title_list
    return df
# set the dataset folder
datasetFolderName = "PythonProject_DataStorage"
fileNameList = glob.glob(datasetFolderName + "/*")
# This is the main code for this file, every .xlsx file in the 'datasetFolderName' is read and integrated and cleaned
# Moreover, the sentiments are added, the title and text are filtered, the result is saved in 'concat.xlsx', which is the data source we will use in many other places
df = readDatasets(datasetFolderName)
df = add_sentiment(df)
df = remove_stopwords(df)
df.to_excel('concat.xlsx', sheet_name='new_sheet_name')




