# filename : topic_analysis.py
#
# the names of the group members:
# Jianping DENG,jianpind@andrew.cmu.edu
# Shan GAO,shangao@andrew.cmu.edu
# Tan Tan (Zoe) KWAN,tantank@andrew.cmu.edu
# Takuya FUNAHASHI,tfunahas@andrew.cmu.edu
# Yunzhou NING,yunzhoun@andrew.cmu.edu
#
# this module make tipic analysis result

import pandas as pd
import lda
from readExcel import  modifyDf
import numpy as np
import collections
# Read the integrated data source
path = 'concat.xlsx'
df = pd.read_excel(path)
# To see what modifyDf function does, refers to 'readExcel.py', it doesn't matter at this place
df = modifyDf(df)
# Start LDA
print('Fantastic LDA starts here')
# each doc contains all the words from one channel at the date
def runLDA(date, f, type = 'filtered_text'):
    date = int(date)
    bbc = df[(df['source'] == 'BBC') & (df['searchDate'] == date)]
    abc = df[(df['source'] == 'ABC') & (df['searchDate'] == date)]
    folha = df[(df['source'] == 'Folha') & (df['searchDate'] == date)]
    renmin = df[(df['source'] == 'Renmin') & (df['searchDate'] == date)]
    al = df[(df['source'] == 'Aljazeera') & (df['searchDate'] == date)]
    nhk = df[(df['source'] == 'NHK') & (df['searchDate'] == date)]
    # get docs
    docs = [bbc, abc, folha, renmin, al, nhk]
    #display the mapping from the channel to doc
    f.write('==================doc:channel==================\n')
    for i in range(len(docs)):
        f.write("doc {}: {}\n".format(i, docs[i].iloc[0]['source']))
    # Get wordset, which is the set contains all the word in the any source
    wordSet = set()
    #use filtered_text here, can use filtered_title as well
    for doc in docs:
        doc_series = doc[type] # series
        for wordlist in doc_series:
            # In same cases the word read from file is in float type, the try and pass is set to handle this situation
            try:
                for word in wordlist:
                    wordSet.add(word.strip())
            except TypeError:
                pass
    #final_word_list is transformed from wordSet
    final_word_list = list(wordSet)
    word_matrix = []
    # In this loop we calculate the frequency of each word in each doc, the result is a sparse matrix
    for doc in docs:
        doc_series = doc[type]
        doc_words = []
        # The same as the try-except above
        try:
            for wordlist in doc_series:
                doc_words += wordlist
        except TypeError:
            pass
        doc_dict = collections.Counter(doc_words)
        doc_key = list(doc_dict.keys())
        row = []
        for i in range(len(final_word_list)):
            if final_word_list[i] in doc_key:
                row.append(doc_dict[final_word_list[i]])
            else:
                row.append(0)
        word_matrix.append(row)
    #print(word_matrix)
    # matrix we want
    X = np.array(word_matrix)
    #print(X.shape)
    model = lda.LDA(n_topics = 10, n_iter = 1000, random_state = 1)
    model.fit(X)
    #doc-topic distribution
    f.write('==================doc:topic==================\n')
    doc_topic = model.doc_topic_
    f.write(str(doc_topic))  #a row represents the possibility describing one doc belongs to topics
    f.write('\n')
    # topic-word distribution
    f.write('==================topic:word==================\n')
    topic_word = model.topic_word_
    #f.write(type(topic_word))
    f.write(str(topic_word.shape))
    f.write('\n')
    f.write(str(topic_word[:, :3]))  # a row represents a topic, describes the probability distribution of words in this topic, the sum of a row is 1
    f.write('\n')
    # Top 10 weights words in each topic
    n = 10
    f.write('==================topic top' + str(n) + ' word==================\n')
    for i, topic_dist in enumerate(topic_word):
        topic_words = np.array(final_word_list)[np.argsort(topic_dist)][:-(n + 1):-1]
        f.write('*Topic {}\n-{}\n'.format(i, ' '.join(topic_words)))
    # The most possible topic for each doc
    f.write('==================doc best topic==================\n')
    for i in range(6):
        topic_most_pr = doc_topic[i].argmax()
        f.write('doc: {} ,best topic: {}\n'.format(i, topic_most_pr))
# testing code
date_interval = [str(x) for x in range(20190926, 20190931)] + [str(x) for x in range(20191001, 20191004)]
for single_date in date_interval:
    f = open('lda'+single_date+'.txt', 'w', encoding="utf-8")
    runLDA(single_date,f)
    f.close()