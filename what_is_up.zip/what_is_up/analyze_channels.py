# filename : analyze_channels.py
#
# the names of the group members:
# Jianping DENG,jianpind@andrew.cmu.edu
# Shan GAO,shangao@andrew.cmu.edu
# Tan Tan (Zoe) KWAN,tantank@andrew.cmu.edu
# Takuya FUNAHASHI,tfunahas@andrew.cmu.edu
# Yunzhou NING,yunzhoun@andrew.cmu.edu

# This file is used to generate some pictures from matplotlib
# The x-axis is time sequence, the y-axis is the average value of one type of sentiment
# The result is saved as .png
# Some function defined here is reusable at other place
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Read the integrated data from our source
path = 'concat.xlsx'
df = pd.read_excel(path)
# input a date, a type of sentiment and the big dataframe, return a sorted pandas Series of average sentiment for each channel
# sentiment can be 'polarity_of_title', 'polarity_of_text', 'subjectivity_of_title', 'subjectivity_of_text'
def channels_report(date, df, sentiment = 'polarity_of_title'):
    date = int(date)
    bbc = df[(df['source'] == 'BBC') & (df[sentiment] != 0) &(df['searchDate'] == date)]
    abc = df[(df['source'] == 'ABC') & (df[sentiment] != 0) &(df['searchDate'] == date)]
    folha = df[(df['source'] == 'Folha') & (df[sentiment] != 0) &(df['searchDate'] == date)]
    renmin = df[(df['source'] == 'Renmin') & (df[sentiment] != 0) &(df['searchDate'] == date)]
    aljazeera = df[(df['source'] == 'Aljazeera') & (df[sentiment] != 0) &(df['searchDate'] == date)]
    nhk = df[(df['source'] == 'NHK') & (df[sentiment] != 0) &(df['searchDate'] == date)]
    # Transform the column of required sentiment in each source to a numpy array, so we can use numpy function to do the calculation
    a_bbc = np.array(bbc[sentiment])
    a_abc = np.array(abc[sentiment])
    a_folha = np.array(folha[sentiment])
    a_renmin = np.array(renmin[sentiment])
    a_aljazeera = np.array(aljazeera[sentiment])
    a_nhk = np.array(nhk[sentiment])
    # Based on the numpy array for each source, calculate the average emotion for them, and assembly them in a dict
    sentiment_dict = {'BBC':a_bbc.mean(), 'ABC':a_abc.mean(), 'Folha':a_folha.mean(), 'Renmin': a_renmin.mean(), 'Aljazeera':a_aljazeera.mean(), 'NHK':a_nhk.mean()}
    # Dict is not possible to sort, so transform to DataFrame
    df_positive = pd.Series(sentiment_dict)
    #Sort the dataFrame
    df_positive.sort_values()
    return df_positive

# generate the input for the plotting, row is date, column is channel, this function is called from function "draw_picture"
def get_plot_input(emotion_type):
    date_interval = [str(x) for x in range(20190926, 20190931)] + [str(x) for x in range(20191001, 20191004)]
    df_plot_input = pd.DataFrame(columns= ['BBC','ABC', 'Folha', 'Renmin', 'Aljazeera', 'NHK'], index = date_interval)
    for single_date in date_interval:
        df_temp = channels_report(single_date, df, emotion_type)
        df_temp.name = single_date
        df_plot_input.loc[single_date] = df_temp
    return df_plot_input

def draw_picture(emotion_type):
    df_plot_input = get_plot_input(emotion_type)
    text_plot = df_plot_input.plot(marker='.', linestyle='-', linewidth=0.5)
    text_plot.set_ylabel(emotion_type.capitalize())
    plt.title(emotion_type.capitalize().replace('_',' ') + " for each channel")
    text_plot.set_xticklabels(["0926", "0927", "0928", "0929", "0930","1001","1002","1003"])
    plt.savefig(emotion_type + '.png')
    plt.show()
# Draw picture for each type
emotion_list = ['polarity_of_text', 'polarity_of_title','subjectivity_of_text','subjectivity_of_title']
for one_emotion in emotion_list:
    draw_picture(one_emotion)
