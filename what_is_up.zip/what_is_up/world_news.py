# filename : world_news.py
#
# the names of the group members:
# Jianping DENG,jianpind@andrew.cmu.edu
# Shan GAO,shangao@andrew.cmu.edu
# Tan Tan (Zoe) KWAN,tantank@andrew.cmu.edu
# Takuya FUNAHASHI,tfunahas@andrew.cmu.edu
# Yunzhou NING,yunzhoun@andrew.cmu.edu

# This is our file of user interface based primarily on tkinter, this module als uses some functions in other file, which
# is imported as below.
# For this file we will not do that much comments, since it will be too text heavy to explain each part of over interface.
# Demo is a better way to understand this file.
# To start the interface, just run this file and wait for 2 seconds
from tkinter import *
from tkinter.ttk import *
import news_eachsource as ne
import tkinter.font as tkFont
from PIL import Image, ImageTk
import find_relevant as fr
import pandas as pd

newsSourceList = ["NHK", "ABC", "BBC", "Renmin", "Aljazeera", "Folha"]
# When Search Button has Pushed or Query Has Entered

# These three functions work together and make response when users click search button
def search(event):
    # get query Input
    query = queryInputBox.get()
    date_text = combo_date.get()
    date_text = date_text[-4:] + date_text[3:5] + date_text[0:2]

    for newsSource in newsSourceList:
        sub_df = ne.get_news_for_source_OrderByIndex(date_text, newsSource)
        sub_df = searchKeyword(query, sub_df)
        if (len(sub_df) < 3):
            for i in range(len(sub_df), 3):
                sub_df = sub_df.append(pd.DataFrame([[newsSource, "None", "None", "None", "None", "None"]], index=['0'],
                                                    columns=['source', 'searchDate', 'title', 'link', 'date', 'text']))
        modifyContents(newsSource, sub_df)
    return None

def searchKeyword(query, df):
    title_b_list = df['title'].str.contains(query)
    text_b_list = df['text'].str.contains(query)

    title_b_list = title_b_list.fillna(False)
    text_b_list = text_b_list.fillna(False)

    return df[title_b_list + text_b_list]
    
def modifyContents(newsSource, inputDf):
    if newsSource == "NHK":
        modify_NHK(inputDf)
    elif newsSource == "ABC":
        modify_ABC(inputDf)
    elif newsSource == "BBC":
        modify_BBC(inputDf)
    elif newsSource == "Renmin":
        modify_Renmin(inputDf)
    elif newsSource == "Aljazeera":
        modify_ALJ(inputDf)
    elif newsSource == "Folha":
        modify_Folha(inputDf)

# This function will give details of news when users click details button
def onclick(sr):
    window = Toplevel()
    title = sr['title']
    link = sr['link']
    date = str(sr['searchDate'])
    try:
        summary = str(sr['text'])
    except:
        summary = 'no text available'

    Label(window, text='Title: ' + '\n' + title + '\n', wraplength=500).grid(row=0, column=0, sticky='w')
    Label(window, text='Link: ' + '\n' + link + '\n', wraplength=500).grid(row=1, column=0, sticky='w')
    Label(window, text='Date' + '\n' + date + '\n', wraplength=500).grid(row=2, column=0, sticky='w')
    Label(window, text='Summary' + '\n' + summary + '\n', wraplength=500).grid(row=3, column=0, sticky='w')

    window.transient(root)
    window.mainloop()

# This function change the contents displayed when users choose different date
def selectedComboBox(event):
    date_text = combo_date.get()
    date_text = date_text[-4:] + date_text[3:5] + date_text[0:2]
    nhk_df = ne.get_news_for_source(date_text, "NHK")
    modify_NHK(nhk_df)
    abc_df = ne.get_news_for_source(date_text, "ABC")
    modify_ABC(abc_df)
    bbc_df = ne.get_news_for_source(date_text, "BBC")
    modify_BBC(bbc_df)
    renmin_df = ne.get_news_for_source(date_text, "Renmin")
    modify_Renmin(renmin_df)
    ALJ_df = ne.get_news_for_source(date_text, "Aljazeera")
    modify_ALJ(ALJ_df)
    folha_df = ne.get_news_for_source(date_text, "Folha")
    modify_Folha(folha_df)

    return None

# This function return the result of LDA analysis when users click the LDA button
def ldaButton_click():
    window = Toplevel()
    date_text = combo_date.get()
    date_text = date_text[-4:] + date_text[3:5] + date_text[0:2]
    y_bar = Scrollbar(window, orient=VERTICAL)
    y_bar.pack(side=RIGHT, fill=Y)
    text_area=Text(window, yscrollcommand=y_bar.set,wrap=WORD)
    y_bar['command'] = text_area.yview
    with open('lda/' + 'lda'+date_text+'.txt', 'r', encoding='UTF-8') as f:
        for line in f:
            text_area.insert(INSERT, line)
    text_area.pack(expand=1, fill=BOTH)
    window.transient(root)
    window.mainloop()
    return None

# This function returns word clould when users click the LDA button
def wordCloudButton_click():
    window = Toplevel()
    date_text = combo_date.get()
    date_text = date_text[-4:] + date_text[3:5] + date_text[0:2]
    image = Image.open('img/'+date_text + '.jpg')
    photo = ImageTk.PhotoImage(image)
    Label(window, image = photo).pack()
    window.transient(root)
    window.mainloop()
    return None

# This function displays the fluctuation of emotion indexes in a visualized way when users click the LDA button
def emoGraphButton_click():
    window = Toplevel()
    image1 = Image.open('img/polarity_of_text.png')
    image2 = Image.open('img/polarity_of_title.png')
    image3 = Image.open('img/subjectivity_of_text.png')
    image4 = Image.open('img/subjectivity_of_title.png')
    photo1 = ImageTk.PhotoImage(image1)
    photo2 = ImageTk.PhotoImage(image2)
    photo3 = ImageTk.PhotoImage(image3)
    photo4 = ImageTk.PhotoImage(image4)

    Label(window, image=photo1).grid(row=0, column=0)
    Label(window, image=photo2).grid(row=0, column=1)
    Label(window, image=photo3).grid(row=1, column=0)
    Label(window, image=photo4).grid(row=1, column=1)
    window.transient(root)
    window.mainloop()
    return None

# This function shows the correlationship between stock and emotion indexes
def regAnalysis_click():
    window = Toplevel()
    image = Image.open('img/reg.jpg')
    photo = ImageTk.PhotoImage(image)
    Label(window, image=photo).pack()
    window.transient(root)
    window.mainloop()
    return None

# This function returns 6 relevant news when users click the find relevant button
def findRelevant(sr):
    window = Toplevel()
    Label(window, text='Relevant News: \n', font=ft_2).grid(row=0, column=0, sticky='w', padx=5, pady=5)
    r_df = fr.find_by_title(sr)
    re_1 = r_df.iloc[0]
    re_2 = r_df.iloc[1]
    re_3 = r_df.iloc[2]
    re_4 = r_df.iloc[3]
    re_5 = r_df.iloc[4]
    re_6 = r_df.iloc[5]

    r_1 = StringVar()
    r_1.set(r_df.iloc[0]['title'])
    r_2 = StringVar()
    r_2.set(r_df.iloc[1]['title'])
    r_3 = StringVar()
    r_3.set(r_df.iloc[2]['title'])
    r_4 = StringVar()
    r_4.set(r_df.iloc[3]['title'])
    r_5 = StringVar()
    r_5.set(r_df.iloc[5]['title'])
    r_6 = StringVar()
    r_6.set(r_df.iloc[6]['title'])
    Label(window, textvariable=r_1, wraplength=250).grid(row=1, column=0, sticky='w', padx=5, pady=5)
    Button(window, text='Details', command=lambda: onclick(re_1)).grid(row=1, column=1, sticky='w',
                                                                              padx=5, pady=5)
    Label(window, textvariable=r_2, wraplength=250).grid(row=2, column=0, sticky='w', padx=5, pady=5)
    Button(window, text='Details', command=lambda: onclick(re_2)).grid(row=2, column=1, sticky='w',
                                                                              padx=5, pady=5)
    Label(window, textvariable=r_3, wraplength=250).grid(row=3, column=0, sticky='w', padx=5, pady=5)
    Button(window, text='Details', command=lambda: onclick(re_3)).grid(row=3, column=1, sticky='w',
                                                                              padx=5, pady=5)
    Label(window, textvariable=r_4, wraplength=250).grid(row=4, column=0, sticky='w', padx=5, pady=5)
    Button(window, text='Details', command=lambda: onclick(re_4)).grid(row=4, column=1, sticky='w',
                                                                              padx=5, pady=5)
    Label(window, textvariable=r_5, wraplength=250).grid(row=5, column=0, sticky='w', padx=5, pady=5)
    Button(window, text='Details', command=lambda: onclick(re_5)).grid(row=5, column=1, sticky='w',
                                                                              padx=5, pady=5)
    Label(window, textvariable=r_6, wraplength=250).grid(row=6, column=0, sticky='w', padx=5, pady=5)
    Button(window, text='Details', command=lambda: onclick(re_6)).grid(row=6, column=1, sticky='w',
                                                                              padx=5, pady=5)
    window.transient(root)
    window.mainloop()
    return None

# This function changes the contents of NHK when users choose different date.
def modify_NHK(inputDf):
    global nhk_but_1, nhk_but_2, nhk_but_3,nhk_but_1r,nhk_but_2r,nhk_but_3r
    nhk_1.set(inputDf.iloc[0]['title'])
    nhk_sr_1 = inputDf.iloc[0]
    nhk_2.set(inputDf.iloc[1]['title'])
    nhk_sr_2 = inputDf.iloc[1]
    nhk_3.set(inputDf.iloc[2]['title'])
    nhk_sr_3 = inputDf.iloc[2]
    nhk_frame.grid_forget()
    nhk_but_1 = Button(nhk_frame, text='Details', command=lambda: onclick(nhk_sr_1)).grid(row=2, column=1, sticky='w',
                                                                                          padx=5, pady=5)
    nhk_but_1r=Button(nhk_frame, text='Find relevant', command=lambda: findRelevant(nhk_sr_1)).grid(row=2, column=2, sticky='w',
                                                                                         padx=5, pady=5)
    nhk_but_2 = Button(nhk_frame, text='Details', command=lambda: onclick(nhk_sr_2)).grid(row=3, column=1, sticky='w',
                                                                                          padx=5, pady=5)
    nhk_but_2r=Button(nhk_frame, text='Find relevant', command=lambda: findRelevant(nhk_sr_2)).grid(row=3, column=2, sticky='w',
                                                                                         padx=5, pady=5)
    nhk_but_3 = Button(nhk_frame, text='Details', command=lambda: onclick(nhk_sr_3)).grid(row=4, column=1, sticky='w',
                                                                                          padx=5, pady=5)
    nhk_but_3r=Button(nhk_frame, text='Find relevant', command=lambda: findRelevant(nhk_sr_3)).grid(row=4, column=2, sticky='w',
                                                                                         padx=5, pady=5)
    nhk_frame.grid(row=0, column=1, sticky='nsew')

# This function changes the contents of ABC when users choose different date.
def modify_ABC(inputDf):
    global abc_but_1, abc_but_2, abc_but_3, abc_but_1r,abc_but_2r,abc_but_3r
    abc_1.set(inputDf.iloc[0]['title'])
    abc_sr_1 = inputDf.iloc[0]
    abc_2.set(inputDf.iloc[1]['title'])
    abc_sr_2 = inputDf.iloc[1]
    abc_3.set(inputDf.iloc[2]['title'])
    abc_sr_3 = inputDf.iloc[2]
    abc_frame.grid_forget()
    abc_but_1 = Button(abc_frame, text='Details', command=lambda: onclick(abc_sr_1)).grid(row=2, column=1, sticky='w',
                                                                                          padx=5, pady=5)
    abc_but_1r=Button(abc_frame, text='Find relevant', command=lambda: findRelevant(abc_sr_1)).grid(row=2, column=2, sticky='w',
                                                                                         padx=5, pady=5)
    abc_but_2 = Button(abc_frame, text='Details', command=lambda: onclick(abc_sr_2)).grid(row=3, column=1, sticky='w',
                                                                                          padx=5, pady=5)
    abc_but_2r=Button(abc_frame, text='Find relevant', command=lambda: findRelevant(abc_sr_2)).grid(row=3, column=2, sticky='w',
                                                                                         padx=5, pady=5)
    abc_but_3 = Button(abc_frame, text='Details', command=lambda: onclick(abc_sr_3)).grid(row=4, column=1, sticky='w',
                                                                                          padx=5, pady=5)
    abc_but_3r=Button(abc_frame, text='Find relevant', command=lambda: findRelevant(abc_sr_3)).grid(row=4, column=2, sticky='w',
                                                                                         padx=5, pady=5)
    abc_frame.grid(row=0, column=2, sticky='nsew')

# This function changes the contents of BBC when users choose different date.
def modify_BBC(inputDf):
    global bbc_but_1, bbc_but_2, bbc_but_3,bbc_but_1r,bbc_but_2r,bbc_but_3r
    bbc_1.set(inputDf.iloc[0]['title'])
    bbc_sr_1 = inputDf.iloc[0]
    bbc_2.set(inputDf.iloc[1]['title'])
    bbc_sr_2 = inputDf.iloc[1]
    bbc_3.set(inputDf.iloc[2]['title'])
    bbc_sr_3 = inputDf.iloc[2]
    bbc_frame.grid_forget()
    bbc_but_1 = Button(bbc_frame, text='Details', command=lambda: onclick(bbc_sr_1)).grid(row=2, column=1, sticky='w',
                                                                                          padx=5, pady=5)
    bbc_but_1r=Button(bbc_frame, text='Find relevant', command=lambda: findRelevant(bbc_sr_1)).grid(row=2, column=2, sticky='w',
                                                                                         padx=5, pady=5)
    bbc_but_2 = Button(bbc_frame, text='Details', command=lambda: onclick(bbc_sr_2)).grid(row=3, column=1, sticky='w',
                                                                                          padx=5, pady=5)
    bbc_but_2r=Button(bbc_frame, text='Find relevant', command=lambda: findRelevant(bbc_sr_2)).grid(row=3, column=2, sticky='w',
                                                                                         padx=5, pady=5)
    bbc_but_3 = Button(bbc_frame, text='Details', command=lambda: onclick(bbc_sr_3)).grid(row=4, column=1, sticky='w',
                                                                                          padx=5, pady=5)
    bbc_but_3r=Button(bbc_frame, text='Find relevant', command=lambda: findRelevant(bbc_sr_3)).grid(row=4, column=2, sticky='w',
                                                                                         padx=5, pady=5)
    bbc_frame.grid(row=0, column=3, sticky='nsew')

# This function changes the contents of people's Daily when users choose different date.
def modify_Renmin(inputDf):
    global people_but_1, people_but_2, people_but_3,people_but_1r,people_but_2r,people_but_3r
    people_1.set(inputDf.iloc[0]['title'])
    people_sr_1 = inputDf.iloc[0]
    people_2.set(inputDf.iloc[1]['title'])
    people_sr_2 = inputDf.iloc[1]
    people_3.set(inputDf.iloc[2]['title'])
    people_sr_3 = inputDf.iloc[2]
    people_frame.grid_forget()
    people_but_1 = Button(people_frame, text='Details', command=lambda: onclick(people_sr_1)).grid(row=2, column=1,
                                                                                                   sticky='w', padx=5,
                                                                                                   pady=5)
    people_but_1r = Button(people_frame, text='Find relevant', command=lambda: findRelevant(people_sr_1)).grid(row=2, column=2,
                                                                                               sticky='w', padx=5,
                                                                                               pady=5)
    people_but_2 = Button(people_frame, text='Details', command=lambda: onclick(people_sr_2)).grid(row=3, column=1,
                                                                                                   sticky='w', padx=5,
                                                                                                   pady=5)
    people_but_2r =Button(people_frame, text='Find relevant', command=lambda: findRelevant(people_sr_2)).grid(row=3, column=2,
                                                                                               sticky='w', padx=5,
                                                                                               pady=5)
    people_but_3 = Button(people_frame, text='Details', command=lambda: onclick(people_sr_3)).grid(row=4, column=1,
                                                                                                   sticky='w', padx=5,
                                                                                                   pady=5)
    people_but_3r =Button(people_frame, text='Find relevant', command=lambda: findRelevant(people_sr_3)).grid(row=4, column=2,
                                                                                               sticky='w', padx=5,
                                                                                               pady=5)
    people_frame.grid(row=1, column=1, sticky='nsew')

# This function changes the contents of ALJ when users choose different date.
def modify_ALJ(inputDf):
    global ALJ_but_1, ALJ_but_2, ALJ_but_3,ALJ_but_1r,ALJ_but_2r,ALJ_but_3r
    ALJ_1.set(inputDf.iloc[0]['title'])
    ALJ_sr_1 = inputDf.iloc[0]
    ALJ_2.set(inputDf.iloc[1]['title'])
    ALJ_sr_2 = inputDf.iloc[1]
    ALJ_3.set(inputDf.iloc[2]['title'])
    ALJ_sr_3 = inputDf.iloc[2]
    ALJ_frame.grid_forget()
    ALJ_but_1 = Button(ALJ_frame, text='Details', command=lambda: onclick(ALJ_sr_1)).grid(row=2, column=1, sticky='w',
                                                                                          padx=5, pady=5)
    ALJ_but_1r = Button(ALJ_frame, text='Find relevant', command=lambda: findRelevant(ALJ_sr_1)).grid(row=2, column=2, sticky='w',
                                                                                         padx=5, pady=5)
    ALJ_but_2 = Button(ALJ_frame, text='Details', command=lambda: onclick(ALJ_sr_2)).grid(row=3, column=1, sticky='w',
                                                                                          padx=5, pady=5)
    ALJ_but_2r =Button(ALJ_frame, text='Find relevant', command=lambda: findRelevant(ALJ_sr_2)).grid(row=3, column=2, sticky='w',
                                                                                         padx=5, pady=5)
    ALJ_but_3 = Button(ALJ_frame, text='Details', command=lambda: onclick(ALJ_sr_3)).grid(row=4, column=1, sticky='w',
                                                                                          padx=5, pady=5)
    ALJ_but_3r =Button(ALJ_frame, text='Find relevant', command=lambda: findRelevant(ALJ_sr_3)).grid(row=4, column=2, sticky='w',
                                                                                         padx=5, pady=5)
    ALJ_frame.grid(row=1, column=2, sticky='nsew')

# This function changes the contents of Folha when users choose different date.
def modify_Folha(inputDf):
    global Folha_but_1, Folha_but_2, Folha_but_3,Folha_but_1r,Folha_but_2r,Folha_but_3r
    Folha_1.set(inputDf.iloc[0]['title'])
    Folha_sr_1 = inputDf.iloc[0]
    Folha_2.set(inputDf.iloc[1]['title'])
    Folha_sr_2 = inputDf.iloc[1]
    Folha_3.set(inputDf.iloc[2]['title'])
    Folha_sr_3 = inputDf.iloc[2]
    Folha_frame.grid_forget()
    Folha_but_1 = Button(Folha_frame, text='Details', command=lambda: onclick(Folha_sr_1)).grid(row=2, column=1,
                                                                                                sticky='w', padx=5,
                                                                                                pady=5)
    Folha_but_1r = Button(Folha_frame, text='Find relevant', command=lambda: findRelevant(Folha_sr_1)).grid(row=2, column=2,
                                                                                             sticky='w', padx=5, pady=5)
    Folha_but_2 = Button(Folha_frame, text='Details', command=lambda: onclick(Folha_sr_2)).grid(row=3, column=1,
                                                                                                sticky='w', padx=5,
                                                                                                pady=5)
    Folha_but_2r = Button(Folha_frame, text='Find relevant', command=lambda: findRelevant(Folha_sr_2)).grid(row=3, column=2,
                                                                                             sticky='w', padx=5, pady=5)
    Folha_but_3 = Button(Folha_frame, text='Details', command=lambda: onclick(Folha_sr_3)).grid(row=4, column=1,
                                                                                                sticky='w', padx=5,
                                                                                                pady=5)
    Folha_but_3r = Button(Folha_frame, text='Find relevant', command=lambda: findRelevant(Folha_sr_3)).grid(row=4, column=2,
                                                                                             sticky='w', padx=5, pady=5)
    Folha_frame.grid(row=1, column=3, sticky='nsew')


root = Tk()
root.title('World News')
root.grid_columnconfigure(1, weight=1)
root.grid_rowconfigure(1, weight=1)


# Create the frame of interactive functions
function_frame = Frame(root, width=400, height=800, borderwidth=1, relief='flat')

# row 1
date_label = Label(function_frame, text='Date')
date_label.grid(row=1, column=1, sticky='nw', padx=5, pady=5)

combo_date = Combobox(function_frame, values=['26-09-2019', '27-09-2019', '28-09-2019', '29-09-2019', '30-09-2019',
                                              '01-10-2019', '02-10-2019', '03-10-2019'])
combo_date.current(0)
combo_date.bind('<<ComboboxSelected>>', selectedComboBox)
combo_date.grid(row=1, column=2, columnspan=2, sticky='ne', padx=5, pady=5)

# row 2 : Padding
data_label_forPadding1 = Label(function_frame, text="\n")
data_label_forPadding1.grid(row=2, column=1, columnspan=4, sticky="nesw")

# row 3 : Search Button
queryInputBox = Entry(function_frame)
queryInputBox.bind('<Return>', search)
queryInputBox .grid(row=3, column=1, columnspan=3,sticky = "new")

#searchButton = Button(function_frame, text=u'search', command=search)
searchButton = Button(function_frame, text=u'search')
searchButton.bind('<Button-1>', search)
searchButton.grid(row=3, column=4)

# row 4 : Padding
data_label_forPadding2 = Label(function_frame, text="\n")
data_label_forPadding2.grid(row=4, column=1, columnspan=4, sticky="nesw")

# row 5 : analyze buttons
show_wordCloudButton = Button(function_frame, text='Word\nCloud', command=lambda: wordCloudButton_click())
show_wordCloudButton.grid(row=5, column=1, padx=1, pady=1, sticky="nesw")

show_LDAButton = Button(function_frame, text='LDA', command=lambda: ldaButton_click())
show_LDAButton.grid(row=5, column=2, padx=1, pady=1, sticky="nesw")

show_EmoGraphButton = Button(function_frame, text='Emo\nGraph', command=lambda: emoGraphButton_click())
show_EmoGraphButton.grid(row=5, column=3, padx=1, pady=1, sticky="nesw")

show_RegAnalysisButton = Button(function_frame, text='Regression\nAnalysis', command=lambda: regAnalysis_click())
show_RegAnalysisButton.grid(row=5, column=4, padx=1, pady=1, sticky="nesw")

function_frame.grid(row=0, column=0, sticky='nsew')


ft_1 = tkFont.Font(size=48, weight=tkFont.BOLD)
ft_2 = tkFont.Font(weight=tkFont.BOLD)

#Create the frame of NHK
nhk_frame = Frame(root, width=400, height=400, borderwidth=1, relief='sunken')
nhk_title = Label(nhk_frame, text='NHK', font=ft_1)
nhk_title.grid(row=0)
nhk_df_26 = ne.get_news_for_source('20190926', 'NHK')
nhk_sr_1 = nhk_df_26.iloc[0]
nhk_sr_2 = nhk_df_26.iloc[1]
nhk_sr_3 = nhk_df_26.iloc[2]

nhk_top = 'TOP 3 News: ' + '\n'
nhk_1 = StringVar()
nhk_1.set(nhk_df_26.iloc[0]['title'])
nhk_2 = StringVar()
nhk_2.set(nhk_df_26.iloc[1]['title'])
nhk_3 = StringVar()
nhk_3.set(nhk_df_26.iloc[2]['title'])

nhk_top_news = Label(nhk_frame, text=nhk_top, justify='left', wraplength=200, font=ft_2).grid(row=1, column=0,
                                                                                              sticky='w', padx=5,
                                                                                              pady=5)
nhk_label1 = Label(nhk_frame, textvariable=nhk_1, wraplength=250).grid(row=2, column=0, sticky='w', padx=5, pady=5)
nhk_label2 = Label(nhk_frame, textvariable=nhk_2, wraplength=250).grid(row=3, column=0, sticky='w', padx=5, pady=5)
nhk_label3 = Label(nhk_frame, textvariable=nhk_3, wraplength=250).grid(row=4, column=0, sticky='w', padx=5, pady=5)
nhk_but_1 = Button(nhk_frame, text='Details', command=lambda: onclick(nhk_sr_1)).grid(row=2, column=1, sticky='w',
                                                                                      padx=5, pady=5)
nhk_but_1r = Button(nhk_frame, text='Find relevant', command=lambda: findRelevant(nhk_sr_1)).grid(row=2,column=2,sticky='w',padx=5,pady=5)
nhk_but_2 = Button(nhk_frame, text='Details', command=lambda: onclick(nhk_sr_2)).grid(row=3, column=1, sticky='w',
                                                                                      padx=5, pady=5)
nhk_but_2r = Button(nhk_frame, text='Find relevant', command=lambda: findRelevant(nhk_sr_2)).grid(row=3,column=2,sticky='w',padx=5,pady=5)
nhk_but_3 = Button(nhk_frame, text='Details', command=lambda: onclick(nhk_sr_3)).grid(row=4, column=1, sticky='w',
                                                                                      padx=5, pady=5)
nhk_but_3r = Button(nhk_frame, text='Find relevant', command=lambda: findRelevant(nhk_sr_3)).grid(row=4,column=2,sticky='w',padx=5,pady=5)
nhk_frame.grid(row=0, column=1, sticky='nsew')

#Create the frame of ABC
abc_frame = Frame(root, width=400, height=400, borderwidth=1, relief='sunken')
abc_title = Label(abc_frame, text='ABC', font=ft_1)
abc_title.grid(row=0)
abc_df_26 = ne.get_news_for_source('20190926', 'ABC')
abc_sr_1 = abc_df_26.iloc[0]
abc_sr_2 = abc_df_26.iloc[1]
abc_sr_3 = abc_df_26.iloc[2]

abc_top = 'TOP 3 News: ' + '\n'
abc_1 = StringVar()
abc_1.set(abc_df_26.iloc[0]['title'])
abc_2 = StringVar()
abc_2.set(abc_df_26.iloc[1]['title'])
abc_3 = StringVar()
abc_3.set(abc_df_26.iloc[2]['title'])

abc_top_news = Label(abc_frame, text=abc_top, justify='left', wraplength=200, font=ft_2).grid(row=1, column=0,
                                                                                              sticky='w', padx=5,
                                                                                              pady=5)
Label(abc_frame, textvariable=abc_1, wraplength=250).grid(row=2, column=0, sticky='w', padx=5, pady=5)
Label(abc_frame, textvariable=abc_2, wraplength=250).grid(row=3, column=0, sticky='w', padx=5, pady=5)
Label(abc_frame, textvariable=abc_3, wraplength=250).grid(row=4, column=0, sticky='w', padx=5, pady=5)
abc_but_1 = Button(abc_frame, text='Details', command=lambda: onclick(abc_sr_1)).grid(row=2, column=1, sticky='w',
                                                                                      padx=5, pady=5)
abc_but_1r = Button(abc_frame, text='Find relevant', command=lambda: findRelevant(abc_sr_1)).grid(row=2,column=2,sticky='w',padx=5,pady=5)
abc_but_2 = Button(abc_frame, text='Details', command=lambda: onclick(abc_sr_2)).grid(row=3, column=1, sticky='w',
                                                                                      padx=5, pady=5)
abc_but_2r = Button(abc_frame, text='Find relevant', command=lambda: findRelevant(abc_sr_2)).grid(row=3,column=2,sticky='w',padx=5,pady=5)
abc_but_3 = Button(abc_frame, text='Details', command=lambda: onclick(abc_sr_3)).grid(row=4, column=1, sticky='w',
                                                                                      padx=5, pady=5)
abc_but_3r = Button(abc_frame, text='Find relevant', command=lambda: findRelevant(abc_sr_3)).grid(row=4,column=2,sticky='w',padx=5,pady=5)
abc_frame.grid(row=0, column=2, sticky='nsew')

#Create the frame of BBC
bbc_frame = Frame(root, width=400, height=400, borderwidth=1, relief='sunken')
bbc_title = Label(bbc_frame, text='BBC', font=ft_1)
bbc_title.grid(row=0)
bbc_df_26 = ne.get_news_for_source('20190926', 'BBC')
bbc_sr_1 = bbc_df_26.iloc[0]
bbc_sr_2 = bbc_df_26.iloc[1]
bbc_sr_3 = bbc_df_26.iloc[2]

bbc_top = 'TOP 3 News: ' + '\n'
bbc_1 = StringVar()
bbc_1.set(bbc_df_26.iloc[0]['title'])
bbc_2 = StringVar()
bbc_2.set(bbc_df_26.iloc[1]['title'])
bbc_3 = StringVar()
bbc_3.set(bbc_df_26.iloc[2]['title'])

bbc_top_news = Label(bbc_frame, text=bbc_top, justify='left', wraplength=200, font=ft_2).grid(row=1, column=0,
                                                                                              sticky='w', padx=5,
                                                                                              pady=5)
Label(bbc_frame, textvariable=bbc_1, wraplength=250).grid(row=2, column=0, sticky='w', padx=5, pady=5)
Label(bbc_frame, textvariable=bbc_2, wraplength=250).grid(row=3, column=0, sticky='w', padx=5, pady=5)
Label(bbc_frame, textvariable=bbc_3, wraplength=250).grid(row=4, column=0, sticky='w', padx=5, pady=5)
bbc_but_1 = Button(bbc_frame, text='Details', command=lambda: onclick(bbc_sr_1)).grid(row=2, column=1, sticky='w',
                                                                                      padx=5, pady=5)
bbc_but_1r = Button(bbc_frame, text='Find relevant', command=lambda: findRelevant(bbc_sr_1)).grid(row=2,column=2,sticky='w',padx=5,pady=5)
bbc_but_2 = Button(bbc_frame, text='Details', command=lambda: onclick(bbc_sr_2)).grid(row=3, column=1, sticky='w',
                                                                                      padx=5, pady=5)
bbc_but_2r = Button(bbc_frame, text='Find relevant', command=lambda: findRelevant(bbc_sr_2)).grid(row=3,column=2,sticky='w',padx=5,pady=5)
bbc_but_3 = Button(bbc_frame, text='Details', command=lambda: onclick(bbc_sr_3)).grid(row=4, column=1, sticky='w',
                                                                                      padx=5, pady=5)
bbc_but_3r = Button(bbc_frame, text='Find relevant', command=lambda: findRelevant(bbc_sr_3)).grid(row=4,column=2,sticky='w',padx=5,pady=5)
bbc_frame.grid(row=0, column=3, sticky='nsew')

#Create the frame of People's Daily
people_frame = Frame(root, width=400, height=400, borderwidth=1, relief='sunken')
people_title = Label(people_frame, text='Renmin', font=ft_1)
people_title.grid(row=0)

people_df_26 = ne.get_news_for_source('20190926', 'Renmin')
people_sr_1 = people_df_26.iloc[0]
people_sr_2 = people_df_26.iloc[1]
people_sr_3 = people_df_26.iloc[2]

people_top = 'TOP 3 News: ' + '\n'
people_1 = StringVar()
people_1.set(people_df_26.iloc[0]['title'])
people_2 = StringVar()
people_2.set(people_df_26.iloc[1]['title'])
people_3 = StringVar()
people_3.set(people_df_26.iloc[2]['title'])

people_top_news = Label(people_frame, text=people_top, justify='left', wraplength=200, font=ft_2).grid(row=1, column=0,
                                                                                                       sticky='w',
                                                                                                       padx=5, pady=5)
Label(people_frame, textvariable=people_1, wraplength=250).grid(row=2, column=0, sticky='w', padx=5, pady=5)
Label(people_frame, textvariable=people_2, wraplength=250).grid(row=3, column=0, sticky='w', padx=5, pady=5)
Label(people_frame, textvariable=people_3, wraplength=250).grid(row=4, column=0, sticky='w', padx=5, pady=5)
people_but_1 = Button(people_frame, text='Details', command=lambda: onclick(people_sr_1)).grid(row=2, column=1,
                                                                                               sticky='w', padx=5,
                                                                                               pady=5)
people_but_1r = Button(people_frame, text='Find relevant', command=lambda: findRelevant(people_sr_1)).grid(row=2,column=2,sticky='w',padx=5,pady=5)
people_but_2 = Button(people_frame, text='Details', command=lambda: onclick(people_sr_2)).grid(row=3, column=1,
                                                                                               sticky='w', padx=5,
                                                                                               pady=5)
people_but_2r = Button(people_frame, text='Find relevant', command=lambda: findRelevant(people_sr_2)).grid(row=3,column=2,sticky='w',padx=5,pady=5)
people_but_3 = Button(people_frame, text='Details', command=lambda: onclick(people_sr_3)).grid(row=4, column=1,
                                                                                               sticky='w', padx=5,
                                                                                               pady=5)
people_but_3r = Button(people_frame, text='Find relevant', command=lambda: findRelevant(people_sr_3)).grid(row=4,column=2,sticky='w',padx=5,pady=5)


people_frame.grid(row=1, column=1, sticky='nsew')

#Create the frame of ALJ
ALJ_frame = Frame(root, width=400, height=400, borderwidth=1, relief='sunken')
ft_1 = tkFont.Font(size=48, weight=tkFont.BOLD)
ft_2 = tkFont.Font(weight=tkFont.BOLD)
ALJ_title = Label(ALJ_frame, text='ALJ', font=ft_1)
ALJ_title.grid(row=0)
ALJ_df_26 = ne.get_news_for_source('20190928', 'Aljazeera')
ALJ_sr_1 = ALJ_df_26.iloc[0]
ALJ_sr_2 = ALJ_df_26.iloc[1]
ALJ_sr_3 = ALJ_df_26.iloc[2]

ALJ_top = 'TOP 3 News: ' + '\n'
ALJ_1 = StringVar()
ALJ_1.set(ALJ_df_26.iloc[0]['title'])
ALJ_2 = StringVar()
ALJ_2.set(ALJ_df_26.iloc[1]['title'])
ALJ_3 = StringVar()
ALJ_3.set(ALJ_df_26.iloc[2]['title'])

ALJ_top_news = Label(ALJ_frame, text=ALJ_top, justify='left', wraplength=200, font=ft_2).grid(row=1, column=0,
                                                                                              sticky='w', padx=5,
                                                                                              pady=5)
Label(ALJ_frame, textvariable=ALJ_1, wraplength=250).grid(row=2, column=0, sticky='w', padx=5, pady=5)
Label(ALJ_frame, textvariable=ALJ_2, wraplength=250).grid(row=3, column=0, sticky='w', padx=5, pady=5)
Label(ALJ_frame, textvariable=ALJ_3, wraplength=250).grid(row=4, column=0, sticky='w', padx=5, pady=5)
ALJ_but_1 = Button(ALJ_frame, text='Details', command=lambda: onclick(ALJ_sr_1)).grid(row=2, column=1, sticky='w',
                                                                                      padx=5, pady=5)
ALJ_but_1r = Button(ALJ_frame, text='Find relevant', command=lambda: findRelevant(ALJ_sr_1)).grid(row=2,column=2,sticky='w',padx=5,pady=5)
ALJ_but_2 = Button(ALJ_frame, text='Details', command=lambda: onclick(ALJ_sr_2)).grid(row=3, column=1, sticky='w',
                                                                                      padx=5, pady=5)
ALJ_but_2r = Button(ALJ_frame, text='Find relevant', command=lambda: findRelevant(ALJ_sr_2)).grid(row=3,column=2,sticky='w',padx=5,pady=5)
ALJ_but_3 = Button(ALJ_frame, text='Details', command=lambda: onclick(ALJ_sr_3)).grid(row=4, column=1, sticky='w',
                                                                                      padx=5, pady=5)
ALJ_but_3r = Button(ALJ_frame, text='Find relevant', command=lambda: findRelevant(ALJ_sr_3)).grid(row=4,column=2,sticky='w',padx=5,pady=5)
ALJ_frame.grid(row=1, column=2, sticky='nsew')

#Create the frame of Folha
Folha_frame = Frame(root, width=400, height=400, borderwidth=1, relief='sunken')
ft_1 = tkFont.Font(size=48, weight=tkFont.BOLD)
ft_2 = tkFont.Font(weight=tkFont.BOLD)
Folha_title = Label(Folha_frame, text='Folha', font=ft_1)
Folha_title.grid(row=0)
Folha_df_26 = ne.get_news_for_source('20190928', 'Folha')
Folha_sr_1 = Folha_df_26.iloc[0]
Folha_sr_2 = Folha_df_26.iloc[1]
Folha_sr_3 = Folha_df_26.iloc[2]

Folha_top = 'TOP 3 News: ' + '\n'
Folha_1 = StringVar()
Folha_1.set(Folha_df_26.iloc[0]['title'])
Folha_2 = StringVar()
Folha_2.set(Folha_df_26.iloc[1]['title'])
Folha_3 = StringVar()
Folha_3.set(Folha_df_26.iloc[2]['title'])

Folha_top_news = Label(Folha_frame, text=Folha_top, justify='left', wraplength=200, font=ft_2).grid(row=1, column=0,
                                                                                                    sticky='w', padx=5,
                                                                                                    pady=5)
Label(Folha_frame, textvariable=Folha_1, wraplength=250).grid(row=2, column=0, sticky='w', padx=5, pady=5)
Label(Folha_frame, textvariable=Folha_2, wraplength=250).grid(row=3, column=0, sticky='w', padx=5, pady=5)
Label(Folha_frame, textvariable=Folha_3, wraplength=250).grid(row=4, column=0, sticky='w', padx=5, pady=5)
Folha_but_1 = Button(Folha_frame, text='Details', command=lambda: onclick(Folha_sr_1)).grid(row=2, column=1, sticky='w',
                                                                                            padx=5, pady=5)
Folha_but_1r = Button(Folha_frame, text='Find relevant', command=lambda: findRelevant(Folha_sr_1)).grid(row=2,column=2,sticky='w',padx=5,pady=5)
Folha_but_2 = Button(Folha_frame, text='Details', command=lambda: onclick(Folha_sr_2)).grid(row=3, column=1, sticky='w',
                                                                                            padx=5, pady=5)
Folha_but_2r = Button(Folha_frame, text='Find relevant', command=lambda: findRelevant(Folha_sr_2)).grid(row=3,column=2,sticky='w',padx=5,pady=5)
Folha_but_3 = Button(Folha_frame, text='Details', command=lambda: onclick(Folha_sr_3)).grid(row=4, column=1, sticky='w',
                                                                                            padx=5, pady=5)
Folha_but_3r = Button(Folha_frame, text='Find relevant', command=lambda: findRelevant(Folha_sr_3)).grid(row=4,column=2,sticky='w',padx=5,pady=5)
Folha_frame.grid(row=1, column=3, sticky='nsew')

root.mainloop()